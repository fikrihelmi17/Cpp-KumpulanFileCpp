#include <iostream> //library
#include <cstdlib> //library untuk clear screen


using namespace std;

int pilih,n,i,g,b;


char yes;

struct mahasiswa {
	int npm;
	string nama;
	float nilai;
};
	mahasiswa dataMHS[30];



int main() {
	
	
	awal:
	system("clear");
	cout << "Menu :" << endl;
	cout << "	1. Tambah Data Mahasiswa" << endl;
	cout << "	2. Edit Data Mahasiswa" << endl;
	cout << "	3. Hapus Data Mahasiswa" << endl;
	cout << "	4. Sorting Data Mahasiswa" << endl;
	cout << "	5. Tampilkan Data Mahasiswa" << endl;
	cout << "	6. Exit Program" << endl;
	cout << endl;
	cout << "Menu Pilihan : "; cin >> pilih;
	
	switch (pilih) {
		case 1: 
			system("clear");
			cout << "Jumlah Mahasiswa yang akan diinput : "; cin >> n;
			cout << "\nData mahasiswa : " <<endl;
				for (i=1; i<=n; i++) {
					cout << "\nMasukkan Data Mahasiswa ke " << i << endl;
					cout << "\nNPM		: "; cin >> dataMHS[i].npm; 
					cout << "\nNama		: "; cin >> dataMHS[i].nama;
					cout << "\nNilai		: "; cin >> dataMHS[i].nilai;
				};
			
			cout << "\n\nLanjut? (y) : "; cin >> yes;
		
				if (yes=='y') {
					goto awal;
				}
				else if (yes=='Y') {
					goto awal;
				}
				else
					return 0;
					
		break;
		
		case 2:
		
			system("clear");
			cout << "\nMasukkan indeks data yang akan diubah : "; cin >> g;
			cout << "\nMasukkan data apa yang ingin diganti : "; cin >> b;

		break;
		case 3:
		system("clear");
		cout << "Hai" << endl;
		break;
		case 4:
		system("clear");
		cout << "Hai" << endl;
		break;
		case 5:
			system("clear"); 
			for (i=1; i<=n; i++) {
				cout << "\n\nMahasiswa ke " <<i<< endl;
				cout << "NPM	: " <<dataMHS[i].npm<<endl;
				cout << "Nama	: " <<dataMHS[i].nama<<endl;
				cout << "Nilai	: " <<dataMHS[i].nilai<<endl; 
			}
		break;
		case 6:
		return 0;
		break;
		default : 
		system("clear");
		cout << "Maaf inputan anda salah, silahkan ulangi (y) : ";
		cin >> yes;
		
		if (yes=='y') {
			goto awal;
		}
		else if (yes=='Y') {
			goto awal;
		}
		else
			return 0;
		
		
	}
	

	
	}
